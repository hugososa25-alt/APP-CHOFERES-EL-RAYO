APP CHOFERES - ANDROID
=====================

Nombre: APP Choferes
Paquete: ar.com.elrayo.appchoferes
Tipo: Aplicación Android nativa con WebView
URL conectada:
https://script.google.com/macros/s/AKfycbzldap766JM_VG_RiHuUEjsYVycvfQlYhdV2VtC_XgPSUa7NntNAJ0n0yJlVg0glXgR/exec

Características:
- Se instala como APK, no como acceso directo.
- Abre la APP Choferes en pantalla propia.
- Mantiene almacenamiento web/localStorage del cajero en el celular.
- Admite cámara/galería para adjuntar comprobantes.
- Mantiene el mismo backend de Google Apps Script y Google Sheets.
- Los cambios publicados en la app web siguen viéndose en la APK sin recompilar, salvo cambios nativos.

Para compilar:
- Abrir este proyecto en Android Studio y generar APK, o
- Subirlo a GitHub y ejecutar el workflow Build APK incluido.
