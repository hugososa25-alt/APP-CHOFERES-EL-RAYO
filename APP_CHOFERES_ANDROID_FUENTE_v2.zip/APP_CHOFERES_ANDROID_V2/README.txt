APP Choferes Android v1.0.1
- Carga la web app de Apps Script dentro de WebView.
- Mantiene cookies y redirecciones web dentro de la app.
- Conserva seleccion de cajero via almacenamiento WebView.
- Soporta adjuntar foto/camara para comprobantes.
