APP Choferes Android v1.0.1
- Carga la web app de Apps Script dentro de WebView.
- Mantiene cookies y redirecciones web dentro de la app.
- Conserva seleccion de cajero via almacenamiento WebView.
- Soporta adjuntar foto/camara para comprobantes.

APP Choferes v1.0.2
URL actualizada: https://script.google.com/macros/s/AKfycbz1lfGMkzMqu6Y8yL-hsQiYeh0SNXUVmPBr8O07C1oWjLAJq6SkeRKVMilJGaLCB7QI/exec
