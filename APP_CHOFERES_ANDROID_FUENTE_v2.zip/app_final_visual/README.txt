APP CHOFERES EL RAYO - Android 1.1.0

Incluye de forma real en el APK:
- Icono propio APP Choferes (camion blanco sobre azul).
- Splash nativo: APP CHOFERES / EL RAYO / Rendiciones en tus manos / Cargando...
- URL activa de Apps Script actual.
- Pantalla completa inmersiva con ocultamiento moderno de barras Android.
- WebView con cookies, almacenamiento, camara y selector de imagen.
- No modifica la logica de rendiciones ni las planillas.
