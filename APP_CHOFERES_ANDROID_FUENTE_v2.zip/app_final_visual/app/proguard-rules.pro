# Sin reglas especiales.
