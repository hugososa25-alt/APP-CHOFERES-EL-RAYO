package ar.com.elrayo.appchoferes;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://script.google.com/macros/s/AKfycbz1lfGMkzMqu6Y8yL-hsQiYeh0SNXUVmPBr8O07C1oWjLAJq6SkeRKVMilJGaLCB7QI/exec";
    private static final int FILE_CHOOSER = 1201;
    private static final int CAMERA_PERMISSION = 1202;

    private WebView webView;
    private FrameLayout splash;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private long splashInicio;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        activarPantallaCompleta();

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        splash = crearSplash();
        root.addView(splash, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(visibility -> {
            if ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0 ||
                    (visibility & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) {
                getWindow().getDecorView().postDelayed(this::activarPantallaCompleta, 180);
            }
        });
        splashInicio = System.currentTimeMillis();

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " APPChoferes/1.2.1");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if (scheme == null) return false;
                if (scheme.equals("http") || scheme.equals("https")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                if (url.startsWith("http://") || url.startsWith("https://")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                long transcurrido = System.currentTimeMillis() - splashInicio;
                long espera = Math.max(0, 1000 - transcurrido);
                splash.postDelayed(() -> ocultarSplash(), espera);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                abrirSelectorConCamara();
                return true;
            }
        });

        if (savedInstanceState == null) {
            webView.clearHistory();
            webView.loadUrl(APP_URL);
        } else {
            webView.restoreState(savedInstanceState);
            ocultarSplash();
        }
    }

    private FrameLayout crearSplash() {
        FrameLayout fondo = new FrameLayout(this);
        GradientDrawable grad = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(0, 104, 205), Color.rgb(0, 61, 137)});
        fondo.setBackground(grad);

        LinearLayout caja = new LinearLayout(this);
        caja.setOrientation(LinearLayout.VERTICAL);
        caja.setGravity(Gravity.CENTER);
        caja.setPadding(dp(28), dp(36), dp(28), dp(36));

        ImageView camion = new ImageView(this);
        camion.setImageResource(R.drawable.truck_mirian);
        camion.setAdjustViewBounds(true);
        LinearLayout.LayoutParams camionLp = new LinearLayout.LayoutParams(dp(190), dp(135));
        camionLp.bottomMargin = dp(18);
        caja.addView(camion, camionLp);

        TextView titulo = texto("APP CHOFERES", 36, true);
        caja.addView(titulo);

        TextView marca = texto("EL RAYO", 25, true);
        LinearLayout.LayoutParams marcaLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        marcaLp.topMargin = dp(8);
        caja.addView(marca, marcaLp);

        View linea = new View(this);
        linea.setBackgroundColor(Color.rgb(80, 179, 255));
        LinearLayout.LayoutParams lineaLp = new LinearLayout.LayoutParams(dp(185), dp(2));
        lineaLp.topMargin = dp(26);
        lineaLp.bottomMargin = dp(24);
        caja.addView(linea, lineaLp);

        TextView bajada = texto("Rendiciones en tus manos", 18, false);
        caja.addView(bajada);

        ProgressBar progreso = new ProgressBar(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            progreso.getIndeterminateDrawable().setTint(Color.WHITE);
        }
        LinearLayout.LayoutParams progLp = new LinearLayout.LayoutParams(dp(52), dp(52));
        progLp.topMargin = dp(58);
        caja.addView(progreso, progLp);

        TextView cargando = texto("Cargando...", 16, false);
        LinearLayout.LayoutParams cargLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        cargLp.topMargin = dp(10);
        caja.addView(cargando, cargLp);

        FrameLayout.LayoutParams cajaLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        fondo.addView(caja, cajaLp);
        return fondo;
    }

    private TextView texto(String contenido, float sp, boolean negrita) {
        TextView t = new TextView(this);
        t.setText(contenido);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        t.setGravity(Gravity.CENTER);
        if (negrita) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(int value) {
        float densidad = getResources().getDisplayMetrics().density;
        return Math.round(value * densidad);
    }

    private void ocultarSplash() {
        if (splash == null || splash.getVisibility() != View.VISIBLE) return;
        splash.animate().alpha(0f).setDuration(260).withEndAction(() -> {
            splash.setVisibility(View.GONE);
            activarPantallaCompleta();
        }).start();
    }

    private void activarPantallaCompleta() {
        final View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        activarPantallaCompleta();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) activarPantallaCompleta();
    }

    private void abrirSelectorConCamara() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        lanzarSelector(true);
    }

    private void lanzarSelector(boolean incluirCamara) {
        Intent galeria = new Intent(Intent.ACTION_GET_CONTENT);
        galeria.addCategory(Intent.CATEGORY_OPENABLE);
        galeria.setType("image/*");

        Intent camara = null;
        if (incluirCamara) {
            camara = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            try {
                File imagen = crearArchivoImagen();
                cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", imagen);
                camara.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                camara.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception e) {
                camara = null;
            }
        }

        Intent chooser = Intent.createChooser(galeria, "Adjuntar comprobante");
        if (camara != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camara});
        startActivityForResult(chooser, FILE_CHOOSER);
    }

    private File crearArchivoImagen() throws IOException {
        String fecha = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile("COMPROBANTE_" + fecha + "_", ".jpg", dir);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                lanzarSelector(true);
            } else {
                Toast.makeText(this, "La camara no fue autorizada. Podes elegir una imagen guardada.", Toast.LENGTH_LONG).show();
                lanzarSelector(false);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER || fileCallback == null) return;
        Uri[] resultado = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) resultado = new Uri[]{data.getData()};
            else if (cameraUri != null) resultado = new Uri[]{cameraUri};
        }
        fileCallback.onReceiveValue(resultado);
        fileCallback = null;
        cameraUri = null;
        activarPantallaCompleta();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
